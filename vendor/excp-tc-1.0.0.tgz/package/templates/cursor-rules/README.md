# Cursor rules templates (Testing-feature consumers)

Install into consumer repos with **`tc project sync`** from the product TestCases repo root.

## Product TestCases repo (e.g. `ExcpTime.TestCases`, `Alforqan website/TestCases`)

| File | Purpose |
|------|---------|
| `ask-before-optional-steps.mdc` | VIP — ask before test cases, browser, or builds |
| `agent-task-router.mdc` | FAST vs FEATURE vs EXPLORE (FEATURE is opt-in) |
| `never-skip-rules.mdc` | VIP — mandatory rule compliance; no skipping for speed |
| `ask-before-broad-search.mdc` | Caveman ask before wide repo scans |
| `test-case-closeout-list.mdc` | QA run list at end of every task |
| `local-only-no-vcs.mdc` | VIP — never commit or push Testing-feature artifacts |
| `test-case-format.mdc` | Markdown table + `Key` + `Verify` |
| `delivery-waves.mdc` | Staged waves, `Requires` gates ([`docs/standards/delivery-waves.md`](../../docs/standards/delivery-waves.md)) |
| `test-data-sql.mdc` | Optional SQL under `test-data/` |
| `related-code-minimal.mdc` | Per-test Related code — smallest file set for accurate `tc impact` |
| `simple-communication.mdc` | Plain, short replies to the user |
| `backend-automated-tests.mdc` | Backend Keys → xUnit + `dotnet test` in linked API repo |
| `test-cases-product-repo.mdc` | This repo is the canonical test-case store |
| `testing-feature-capabilities.mdc` | Synced feature index + `tc project update` reminder |

Synced markdown docs install to **`.testing-feature/docs/`** from `templates/sync-docs/` (see `manifest.json`).

## Application code repos (e.g. `EXCP_ANGULAR`, Alforqan Frontend/Backend)

| File | Purpose |
|------|---------|
| `never-skip-rules.mdc` | Same mandatory compliance rule |
| `ask-before-broad-search.mdc` | Same ask-before-search rule |
| `test-case-closeout-list.mdc` | Same closeout requirement |
| `related-code-minimal.mdc` | Same minimal Related code rule |
| `simple-communication.mdc` | Same simple communication rule |
| `app-test-cases-location.mdc` | Installed as `test-cases-location.mdc` per linked repo role |
| `testing-feature-capabilities-app.mdc` | Pointer to `.testing-feature/docs/` in the TestCases repo |
| `backend-automated-tests.mdc` | Installed only on **backend** linked app repos |

## Monorepo workspace (optional)

| File | Purpose |
|------|---------|
| `workspace-test-cases-location.mdc` | Workspace-level frontend pointer (`workspaceRoot` in project config) |

Also keep product-specific rules (`vip-documentation-guard.mdc`, UI rules, etc.). **`tc project sync`** does not overwrite them.

## Vendor repo (Testing-feature)

- `test-case-format.mdc` and `test-data-sql.mdc` under `.cursor/rules/` (vendor `test-cases/testing-feature/` only).
- `test-case-closeout-list.mdc` for CLI/tool changes.
- `ui-ux-standards.mdc` when editing `ui/web/` or `tc ui` (see `docs/technical/ui-ux-standards.md`).

When editing templates, update here first, then run **`tc project sync --force`** from each product TestCases repo.
