#!/usr/bin/env node
/**
 * Cursor stop hook: queue impact review when linked app code changed (no auto needs-update).
 * Installed by `tc project sync` into workspaceRoot (see testing-feature.project.json).
 */
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

function drainStdin() {
  try {
    if (process.stdin.isTTY) return;
    process.stdin.setEncoding('utf8');
    process.stdin.read();
  } catch {
    /* optional */
  }
}

function findProjectRoot(startDir) {
  let dir = path.resolve(startDir);
  const { root } = path.parse(dir);
  while (true) {
    if (fs.existsSync(path.join(dir, 'testing-feature.project.json'))) return dir;
    if (dir === root) break;
    dir = path.dirname(dir);
  }
  return undefined;
}

function loadAutoImpactFlags(projectRoot) {
  try {
    const raw = JSON.parse(
      fs.readFileSync(path.join(projectRoot, 'testing-feature.project.json'), 'utf8'),
    );
    const linked = Array.isArray(raw.linkedRepos) && raw.linkedRepos.length > 0;
    if (!linked) return { run: false, args: [], notes: 'Auto-impact' };

    const ai = raw.autoImpact;
    if (ai === false) return { run: false, args: [], notes: 'Auto-impact' };
    if (ai === true || ai === undefined || ai === null) {
      return {
        run: true,
        args: ['impact', '--git', '--queue'],
        notes: 'Auto-impact',
      };
    }
    if (typeof ai === 'object') {
      if (ai.enabled === false || ai.onAgentStop === false) {
        return { run: false, args: [], notes: 'Auto-impact' };
      }
      const notes =
        typeof ai.notesPrefix === 'string' && ai.notesPrefix.trim()
          ? ai.notesPrefix.trim()
          : 'Auto-impact';
      const applyAutomatically = ai.applyAutomatically === true;
      const args = applyAutomatically
        ? ['impact', '--git', '--apply', '--notes', notes]
        : ['impact', '--git', '--queue'];
      return { run: true, args, notes };
    }
    return { run: true, args: ['impact', '--git', '--queue'], notes: 'Auto-impact' };
  } catch {
    return { run: false, args: [], notes: 'Auto-impact' };
  }
}

function resolveTcCommand() {
  const platform = process.platform;
  return platform === 'win32' ? 'tc.cmd' : 'tc';
}

function main() {
  drainStdin();

  const hookDir = path.dirname(fileURLToPath(import.meta.url));
  const workspaceFromHook = path.resolve(hookDir, '..', '..');
  const candidates = [process.cwd(), workspaceFromHook];
  let projectRoot;
  for (const start of candidates) {
    projectRoot = findProjectRoot(start);
    if (projectRoot) break;
  }

  if (!projectRoot) process.exit(0);

  const { run, args } = loadAutoImpactFlags(projectRoot);
  if (!run) process.exit(0);

  const tc = resolveTcCommand();

  try {
    execFileSync(tc, args, {
      cwd: projectRoot,
      stdio: ['ignore', 'pipe', 'pipe'],
      encoding: 'utf8',
      windowsHide: true,
    });
  } catch (err) {
    const stderr = err?.stderr ?? err?.message ?? String(err);
    if (stderr) process.stderr.write(String(stderr).trimEnd() + '\n');
  }

  process.exit(0);
}

main();
