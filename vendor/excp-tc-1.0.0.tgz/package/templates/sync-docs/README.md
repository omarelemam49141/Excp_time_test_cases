# Synced docs (product TestCases repos)

Installed by **`tc project sync`** into **`.testing-feature/docs/`** (local only, gitignored).

When you add a Testing-feature capability:

1. Add or update a markdown file here.
2. Register it in **`manifest.json`** `files`.
3. Mention it in **`capabilities.md`** and in **`testing-feature-capabilities.mdc`**.
4. Bump **`templates/sync-manifest.json`** `version`.
5. Run **`tc project sync --force`** from each product TestCases repo (or **`tc project update`**).
